# -*- coding: utf-8 -*-
# Copyright 2023 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from __future__ import annotations

from typing import MutableMapping, MutableSequence

import proto  # type: ignore

from google.cloud.aiplatform.private_preview.llm_extension.gapic.types import extension
from google.protobuf import struct_pb2  # type: ignore


__protobuf__ = proto.module(
    package='google.cloud.aiplatform.v1beta1',
    manifest={
        'ExecuteExtensionRequest',
        'ExecuteExtensionResponse',
        'RunExtensionRequest',
        'RunExtensionResponse',
    },
)


class ExecuteExtensionRequest(proto.Message):
    r"""Request message for
    [ExtensionExecutionService.ExecuteExtension][google.cloud.aiplatform.v1beta1.ExtensionExecutionService.ExecuteExtension].

    Attributes:
        name (str):
            Required. Name (identifier) of the extension; Format:
            ``projects/{project}/locations/{location}/extensions/{extension}``
        operation_id (str):
            Required.
            [ExtensionOperation.operation_id][google.cloud.aiplatform.v1beta1.ExtensionOperation.operation_id]
            of the operation to be executed in this extension
            deployment.
        operation_params (google.protobuf.struct_pb2.Struct):
            Optional. Request parameters that will be
            used for executing this operation.

            The struct should be in a form of map with param
            name as the key and actual param value as the
            value.
            E.g. If this operation requires a param "name"
            to be set to "abc". you can set this to
            something like {"name": "abc"}.
        runtime_auth_config (google.cloud.aiplatform_v1beta1.types.AuthConfig):
            Optional. Auth config provided at runtime to override the
            default value in [Extension.manifest.auth_config][].
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )
    operation_id: str = proto.Field(
        proto.STRING,
        number=2,
    )
    operation_params: struct_pb2.Struct = proto.Field(
        proto.MESSAGE,
        number=3,
        message=struct_pb2.Struct,
    )
    runtime_auth_config: extension.AuthConfig = proto.Field(
        proto.MESSAGE,
        number=4,
        message=extension.AuthConfig,
    )


class ExecuteExtensionResponse(proto.Message):
    r"""Response message for
    [ExtensionExecutionService.ExecuteExtension][google.cloud.aiplatform.v1beta1.ExtensionExecutionService.ExecuteExtension].

    Attributes:
        output (google.protobuf.struct_pb2.Struct):
            Output from the extension. The output should
            be conformant to the extension's
            manifest/OpenAPI spec. The output can contain
            values for keys like "content", "headers", etc.
    """

    output: struct_pb2.Struct = proto.Field(
        proto.MESSAGE,
        number=1,
        message=struct_pb2.Struct,
    )


class RunExtensionRequest(proto.Message):
    r"""Request message for
    [ExtensionExecutionService.RunExtension][google.cloud.aiplatform.v1beta1.ExtensionExecutionService.RunExtension].

    Attributes:
        name (str):
            Required. Name (identifier) of the extension deployment;
            Format:
            ``projects/{project}/locations/{location}/extensions/{extension}/deployments/{deployment}``
        operation (str):
            Required.
            [ExtensionOperation.operation_id][google.cloud.aiplatform.v1beta1.ExtensionOperation.operation_id]
            of the operation to be executed in this extension
            deployment.
        operation_params (google.protobuf.struct_pb2.Struct):
            Optional. Request parameters that will be
            used for executing this operation.

            The struct should be in a form of map with param
            name as the key and actual param value as the
            value.
            E.g. If this operation requires a param name to
            be set to "abc". you can set this to something
            like {"name": "abc"}.
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )
    operation: str = proto.Field(
        proto.STRING,
        number=2,
    )
    operation_params: struct_pb2.Struct = proto.Field(
        proto.MESSAGE,
        number=3,
        message=struct_pb2.Struct,
    )


class RunExtensionResponse(proto.Message):
    r"""Response message for
    [ExtensionExecutionService.RunExtension][google.cloud.aiplatform.v1beta1.ExtensionExecutionService.RunExtension].

    Attributes:
        output (google.protobuf.struct_pb2.Struct):
            Output from the extension. The output should
            be conformant to the extension's
            manifest/OpenAPI spec. The output can contain
            values for keys like "content", "headers", etc.
    """

    output: struct_pb2.Struct = proto.Field(
        proto.MESSAGE,
        number=1,
        message=struct_pb2.Struct,
    )


__all__ = tuple(sorted(__protobuf__.manifest))
