# -*- coding: utf-8 -*-
# Copyright 2023 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from __future__ import annotations

from typing import MutableMapping, MutableSequence

import proto  # type: ignore

from google.protobuf import timestamp_pb2  # type: ignore


__protobuf__ = proto.module(
    package='google.cloud.aiplatform.v1beta1',
    manifest={
        'HttpElementLocation',
        'AuthType',
        'Extension',
        'ExtensionManifest',
        'ExtensionDeployment',
        'ExtensionOperation',
        'AuthConfig',
    },
)


class HttpElementLocation(proto.Enum):
    r"""Enum of location an HTTP element can be.

    Values:
        HTTP_IN_UNSPECIFIED (0):
            No description available.
        HTTP_IN_QUERY (1):
            No description available.
        HTTP_IN_HEADER (2):
            No description available.
        HTTP_IN_PATH (3):
            No description available.
        HTTP_IN_BODY (4):
            No description available.
        HTTP_IN_COOKIE (5):
            No description available.
    """
    HTTP_IN_UNSPECIFIED = 0
    HTTP_IN_QUERY = 1
    HTTP_IN_HEADER = 2
    HTTP_IN_PATH = 3
    HTTP_IN_BODY = 4
    HTTP_IN_COOKIE = 5


class AuthType(proto.Enum):
    r"""Type of Auth.

    Values:
        AUTH_TYPE_UNSPECIFIED (0):
            No description available.
        NO_AUTH (1):
            No description available.
        API_KEY_AUTH (2):
            No description available.
        HTTP_BASIC_AUTH (3):
            No description available.
        GOOGLE_SERVICE_ACCOUNT_AUTH (4):
            No description available.
    """
    AUTH_TYPE_UNSPECIFIED = 0
    NO_AUTH = 1
    API_KEY_AUTH = 2
    HTTP_BASIC_AUTH = 3
    GOOGLE_SERVICE_ACCOUNT_AUTH = 4


class Extension(proto.Message):
    r"""Extensions are tools for large language models to access
    external data, run computations, etc.

    Attributes:
        name (str):
            The resource name of the Extension.
        display_name (str):
            Required. The display name of the Extension.
        description (str):
            Optional. The description of the Extension.
        create_time (google.protobuf.timestamp_pb2.Timestamp):
            Output only. Timestamp when this Extension
            was created.
        update_time (google.protobuf.timestamp_pb2.Timestamp):
            Output only. Timestamp when this Extension
            was most recently updated.
        etag (str):
            Optional. Used to perform consistent
            read-modify-write updates. If not set, a blind
            "overwrite" update happens.
        manifest (google.cloud.aiplatform_v1beta1.types.ExtensionManifest):
            Required. Manifest of the Extension.
        extension_info (google.cloud.aiplatform_v1beta1.types.Extension.ExtensionInfo):
            Optional. Information about the extension.
        extension_operations (MutableSequence[google.cloud.aiplatform_v1beta1.types.ExtensionOperation]):
            Output only. Supported operations.
    """

    class ExtensionInfo(proto.Message):
        r"""Information of the extension.

        Attributes:
            logo_uri (str):
                URI of the extension logo.
            developers_emails (MutableSequence[str]):
                Emails of the extension developers.
        """

        logo_uri: str = proto.Field(
            proto.STRING,
            number=1,
        )
        developers_emails: MutableSequence[str] = proto.RepeatedField(
            proto.STRING,
            number=2,
        )

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )
    display_name: str = proto.Field(
        proto.STRING,
        number=3,
    )
    description: str = proto.Field(
        proto.STRING,
        number=4,
    )
    create_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=5,
        message=timestamp_pb2.Timestamp,
    )
    update_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=6,
        message=timestamp_pb2.Timestamp,
    )
    etag: str = proto.Field(
        proto.STRING,
        number=7,
    )
    manifest: 'ExtensionManifest' = proto.Field(
        proto.MESSAGE,
        number=9,
        message='ExtensionManifest',
    )
    extension_info: ExtensionInfo = proto.Field(
        proto.MESSAGE,
        number=10,
        message=ExtensionInfo,
    )
    extension_operations: MutableSequence['ExtensionOperation'] = proto.RepeatedField(
        proto.MESSAGE,
        number=11,
        message='ExtensionOperation',
    )


class ExtensionManifest(proto.Message):
    r"""Manifest spec of an Extension needed for runtime execution.

    Attributes:
        name (str):
            Required. Extension name shown to the LLM.
        description (str):
            Required. The natural language description
            shown to the LLM. It should describe the usage
            of the extension, and is essential for the LLM
            to perform reasoning.
        api_spec (google.cloud.aiplatform_v1beta1.types.ExtensionManifest.ApiSpec):
            Required. Immutable. The API specification
            shown to the LLM.
        auth_types (MutableSequence[google.cloud.aiplatform_v1beta1.types.AuthType]):
            Type of auth supported by this extension.
        auth_config (google.cloud.aiplatform_v1beta1.types.AuthConfig):
            Required. Immutable. Type of auth supported
            by this extension.
        extension_selection_examples (MutableSequence[google.cloud.aiplatform_v1beta1.types.ExtensionManifest.ExtensionSelectionExample]):
            Optional. Prompt examples shown to the LLM
            about when to use this extension.
        extension_invocation_examples (MutableSequence[google.cloud.aiplatform_v1beta1.types.ExtensionManifest.ExtensionInvocationExample]):
            Optional. Prompt examples shown to the LLM
            about how to format a request to this extension.
        extension_response_examples (MutableSequence[google.cloud.aiplatform_v1beta1.types.ExtensionManifest.ExtensionResponseExample]):
            Optional. Prompt examples shown to the LLM
            about how to respond to human.
    """

    class ApiSpec(proto.Message):
        r"""The API specification shown to the LLM.

        This message has `oneof`_ fields (mutually exclusive fields).
        For each oneof, at most one member field can be set at the same time.
        Setting any member of the oneof automatically clears all other
        members.

        .. _oneof: https://proto-plus-python.readthedocs.io/en/stable/fields.html#oneofs-mutually-exclusive-fields

        Attributes:
            open_api_yaml (str):
                The API spec in Open API standard and YAML
                format.

                This field is a member of `oneof`_ ``api_spec``.
            open_api_gcs_uri (str):
                Cloud Storage URI pointing to the OpenAPI
                spec.

                This field is a member of `oneof`_ ``api_spec``.
            custom_code_gcs_uri (str):
                Cloud Storage URI pointing to the custom
                code.

                This field is a member of `oneof`_ ``api_spec``.
        """

        open_api_yaml: str = proto.Field(
            proto.STRING,
            number=1,
            oneof='api_spec',
        )
        open_api_gcs_uri: str = proto.Field(
            proto.STRING,
            number=2,
            oneof='api_spec',
        )
        custom_code_gcs_uri: str = proto.Field(
            proto.STRING,
            number=3,
            oneof='api_spec',
        )

    class ExtensionSelectionExample(proto.Message):
        r"""A prompt example shown to the LLM about when to use this
        extension.

        Attributes:
            query (str):
                Query that should be routed to use this
                extension.
            multi_steps (MutableSequence[google.cloud.aiplatform_v1beta1.types.ExtensionManifest.ExtensionSelectionExample.SingleStep]):
                ReAct examples.
        """

        class SingleStep(proto.Message):
            r"""Single step of the LLM's thinking process.

            This message has `oneof`_ fields (mutually exclusive fields).
            For each oneof, at most one member field can be set at the same time.
            Setting any member of the oneof automatically clears all other
            members.

            .. _oneof: https://proto-plus-python.readthedocs.io/en/stable/fields.html#oneofs-mutually-exclusive-fields

            Attributes:
                extension_execution (google.cloud.aiplatform_v1beta1.types.ExtensionManifest.ExtensionSelectionExample.SingleStep.ExtensionExecution):
                    Action to invoke the extension.

                    This field is a member of `oneof`_ ``next_action``.
                respond_to_user (google.cloud.aiplatform_v1beta1.types.ExtensionManifest.ExtensionSelectionExample.SingleStep.RespondToUser):
                    Action to respond to the user.

                    This field is a member of `oneof`_ ``next_action``.
                thought (str):
                    Thought of LLM.
            """

            class ExtensionExecution(proto.Message):
                r"""Describes an invocation to an operation.

                Attributes:
                    operation_id (str):
                        The
                        [ExtensionOperation.operation_id][google.cloud.aiplatform.v1beta1.ExtensionOperation.operation_id]
                        to invoke.
                    extension_instruction (str):
                        Instruction to be formed as the operation
                        request.
                    observation (str):
                        Results of the extension execution.
                """

                operation_id: str = proto.Field(
                    proto.STRING,
                    number=1,
                )
                extension_instruction: str = proto.Field(
                    proto.STRING,
                    number=2,
                )
                observation: str = proto.Field(
                    proto.STRING,
                    number=3,
                )

            class RespondToUser(proto.Message):
                r"""Describes an response to user.
                """

            extension_execution: 'ExtensionManifest.ExtensionSelectionExample.SingleStep.ExtensionExecution' = proto.Field(
                proto.MESSAGE,
                number=2,
                oneof='next_action',
                message='ExtensionManifest.ExtensionSelectionExample.SingleStep.ExtensionExecution',
            )
            respond_to_user: 'ExtensionManifest.ExtensionSelectionExample.SingleStep.RespondToUser' = proto.Field(
                proto.MESSAGE,
                number=3,
                oneof='next_action',
                message='ExtensionManifest.ExtensionSelectionExample.SingleStep.RespondToUser',
            )
            thought: str = proto.Field(
                proto.STRING,
                number=1,
            )

        query: str = proto.Field(
            proto.STRING,
            number=1,
        )
        multi_steps: MutableSequence['ExtensionManifest.ExtensionSelectionExample.SingleStep'] = proto.RepeatedField(
            proto.MESSAGE,
            number=2,
            message='ExtensionManifest.ExtensionSelectionExample.SingleStep',
        )

    class ExtensionInvocationExample(proto.Message):
        r"""A prompt example shown to the LLM about how to format a
        request to this extension.

        Attributes:
            extension_instruction (str):
                Instruction to be formed as the operation
                request.
            operation_id (str):
                The
                [ExtensionOperation.operation_id][google.cloud.aiplatform.v1beta1.ExtensionOperation.operation_id]
                to use.
            thought (str):
                Thought of LLM.
            operation_param (str):
                Params in JSON format. e.g. {"origin": "San
                Jose", "destination": "SFO"}.
            parameters_mentioned (MutableSequence[str]):
                Params mentioned in the instruction.
        """

        extension_instruction: str = proto.Field(
            proto.STRING,
            number=1,
        )
        operation_id: str = proto.Field(
            proto.STRING,
            number=2,
        )
        thought: str = proto.Field(
            proto.STRING,
            number=3,
        )
        operation_param: str = proto.Field(
            proto.STRING,
            number=4,
        )
        parameters_mentioned: MutableSequence[str] = proto.RepeatedField(
            proto.STRING,
            number=5,
        )

    class ExtensionResponseExample(proto.Message):
        r"""A prompt example shown to the LLM about how to translate the
        extension response into human readable message.

        Attributes:
            operation_id (str):
                The
                [ExtensionOperation.operation_id][google.cloud.aiplatform.v1beta1.ExtensionOperation.operation_id]
                invoked.
            response_template (str):
                Template to use to format the response.
        """

        operation_id: str = proto.Field(
            proto.STRING,
            number=1,
        )
        response_template: str = proto.Field(
            proto.STRING,
            number=2,
        )

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )
    description: str = proto.Field(
        proto.STRING,
        number=2,
    )
    api_spec: ApiSpec = proto.Field(
        proto.MESSAGE,
        number=3,
        message=ApiSpec,
    )
    auth_types: MutableSequence['AuthType'] = proto.RepeatedField(
        proto.ENUM,
        number=4,
        enum='AuthType',
    )
    auth_config: 'AuthConfig' = proto.Field(
        proto.MESSAGE,
        number=5,
        message='AuthConfig',
    )
    extension_selection_examples: MutableSequence[ExtensionSelectionExample] = proto.RepeatedField(
        proto.MESSAGE,
        number=6,
        message=ExtensionSelectionExample,
    )
    extension_invocation_examples: MutableSequence[ExtensionInvocationExample] = proto.RepeatedField(
        proto.MESSAGE,
        number=7,
        message=ExtensionInvocationExample,
    )
    extension_response_examples: MutableSequence[ExtensionResponseExample] = proto.RepeatedField(
        proto.MESSAGE,
        number=8,
        message=ExtensionResponseExample,
    )


class ExtensionDeployment(proto.Message):
    r"""An instance of Extension with runtime config.

    Attributes:
        name (str):
            The resource name of the ExtensionDeployment.
        display_name (str):
            Required. The display name of the
            ExtensionDeployment.
        description (str):
            Optional. The description of the
            ExtensionDeployment.
        create_time (google.protobuf.timestamp_pb2.Timestamp):
            Output only. Timestamp when this
            ExtensionDeployment was created.
        update_time (google.protobuf.timestamp_pb2.Timestamp):
            Output only. Timestamp when this
            ExtensionDeployment was most recently updated.
        etag (str):
            Optional. Used to perform consistent
            read-modify-write updates. If not set, a blind
            "overwrite" update happens.
        auth_config (google.cloud.aiplatform_v1beta1.types.AuthConfig):
            Required. Immutable. Auth config needed for
            this ExtensionDeployment.
        manifest (google.cloud.aiplatform_v1beta1.types.ExtensionManifest):
            Output only. Manifest of the
            ExtensionDeployment.
        extension_operations (MutableSequence[google.cloud.aiplatform_v1beta1.types.ExtensionOperation]):
            Output only. Supported operations.
        service_account (str):
            Optional. The service account that the Cloud Run service
            runs as. If not specified, the Compute Engine default
            service account in the project will be used. See
            https://cloud.google.com/compute/docs/access/service-accounts#default_service_account

            This is currently only used for the custom code extension
            (LangChain based customizable runtime extension).
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )
    display_name: str = proto.Field(
        proto.STRING,
        number=3,
    )
    description: str = proto.Field(
        proto.STRING,
        number=4,
    )
    create_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=5,
        message=timestamp_pb2.Timestamp,
    )
    update_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=6,
        message=timestamp_pb2.Timestamp,
    )
    etag: str = proto.Field(
        proto.STRING,
        number=7,
    )
    auth_config: 'AuthConfig' = proto.Field(
        proto.MESSAGE,
        number=8,
        message='AuthConfig',
    )
    manifest: 'ExtensionManifest' = proto.Field(
        proto.MESSAGE,
        number=9,
        message='ExtensionManifest',
    )
    extension_operations: MutableSequence['ExtensionOperation'] = proto.RepeatedField(
        proto.MESSAGE,
        number=10,
        message='ExtensionOperation',
    )
    service_account: str = proto.Field(
        proto.STRING,
        number=11,
    )


class ExtensionOperation(proto.Message):
    r"""Operation of an extension deployment.

    Attributes:
        operation_id (str):
            Operation ID that uniquely identifies the
            operations among the extension deployment. See:
            "Operation Object" in
            https://swagger.io/specification/.

            This field is parsed from the OpenAPI spec. For
            HTTP extensions, if it does not exist in the
            spec, we will generate one from the HTTP method
            and path.
    """

    operation_id: str = proto.Field(
        proto.STRING,
        number=1,
    )


class AuthConfig(proto.Message):
    r"""Auth configuration to run the extension.

    This message has `oneof`_ fields (mutually exclusive fields).
    For each oneof, at most one member field can be set at the same time.
    Setting any member of the oneof automatically clears all other
    members.

    .. _oneof: https://proto-plus-python.readthedocs.io/en/stable/fields.html#oneofs-mutually-exclusive-fields

    Attributes:
        no_auth (google.cloud.aiplatform_v1beta1.types.AuthConfig.NoAuth):
            Config for no auth.

            This field is a member of `oneof`_ ``auth_config``.
        api_key_config (google.cloud.aiplatform_v1beta1.types.AuthConfig.ApiKeyConfig):
            Config for API key auth.

            This field is a member of `oneof`_ ``auth_config``.
        http_basic_auth_config (google.cloud.aiplatform_v1beta1.types.AuthConfig.HttpBasicAuthConfig):
            Config for HTTP Basic auth.

            This field is a member of `oneof`_ ``auth_config``.
        google_service_account_config (google.cloud.aiplatform_v1beta1.types.AuthConfig.GoogleServiceAccountConfig):
            Config for Google Service Account auth.

            This field is a member of `oneof`_ ``auth_config``.
        auth_type (google.cloud.aiplatform_v1beta1.types.AuthType):
            Type of auth scheme.
    """

    class NoAuth(proto.Message):
        r"""Empty message, used to indicate no authentication for an
        endpoint.

        """

    class ApiKeyConfig(proto.Message):
        r"""Config for authentication with API key.

        Attributes:
            name (str):
                The parameter name of the API key. E.g. If the API request
                is "https://example.com/act?api_key=", "api_key" would be
                the parameter name.
            api_key_secret (str):
                The name of the SecretManager secret version resource
                storing the API key. Format:
                ``projects/{project}/secrets/{secrete}/versions/{version}``
            http_element_location (google.cloud.aiplatform_v1beta1.types.HttpElementLocation):
                The location of the API key.
        """

        name: str = proto.Field(
            proto.STRING,
            number=1,
        )
        api_key_secret: str = proto.Field(
            proto.STRING,
            number=2,
        )
        http_element_location: 'HttpElementLocation' = proto.Field(
            proto.ENUM,
            number=3,
            enum='HttpElementLocation',
        )

    class HttpBasicAuthConfig(proto.Message):
        r"""Config for HTTP Basic Authentication.

        Attributes:
            credential_secret (str):
                The name of the SecretManager secret version resource
                storing the base64 encoded credentials. Format:
                ``projects/{project}/secrets/{secrete}/versions/{version}``
        """

        credential_secret: str = proto.Field(
            proto.STRING,
            number=2,
        )

    class GoogleServiceAccountConfig(proto.Message):
        r"""Config for Google Service Account Authentication.

        Attributes:
            service_account (str):
                The service account that the extension execution service
                runs as.

                -  If it is not specified, the Vertex AI Service Agent
                   (https://cloud.google.com/vertex-ai/docs/general/access-control#service-agents)
                   will be used.
                -  If the service account is provided, the service account
                   should grant Vertex AI Service Agent
                   ``iam.serviceAccounts.getAccessToken`` permission.
        """

        service_account: str = proto.Field(
            proto.STRING,
            number=1,
        )

    no_auth: NoAuth = proto.Field(
        proto.MESSAGE,
        number=1,
        oneof='auth_config',
        message=NoAuth,
    )
    api_key_config: ApiKeyConfig = proto.Field(
        proto.MESSAGE,
        number=2,
        oneof='auth_config',
        message=ApiKeyConfig,
    )
    http_basic_auth_config: HttpBasicAuthConfig = proto.Field(
        proto.MESSAGE,
        number=3,
        oneof='auth_config',
        message=HttpBasicAuthConfig,
    )
    google_service_account_config: GoogleServiceAccountConfig = proto.Field(
        proto.MESSAGE,
        number=4,
        oneof='auth_config',
        message=GoogleServiceAccountConfig,
    )
    auth_type: 'AuthType' = proto.Field(
        proto.ENUM,
        number=101,
        enum='AuthType',
    )


__all__ = tuple(sorted(__protobuf__.manifest))
