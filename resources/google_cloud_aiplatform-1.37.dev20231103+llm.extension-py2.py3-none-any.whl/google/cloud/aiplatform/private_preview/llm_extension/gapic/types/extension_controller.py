# -*- coding: utf-8 -*-
# Copyright 2023 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from __future__ import annotations

from typing import MutableMapping, MutableSequence

import proto  # type: ignore

from google.protobuf import timestamp_pb2  # type: ignore


__protobuf__ = proto.module(
    package='google.cloud.aiplatform.v1beta1',
    manifest={
        'ExtensionController',
        'ExtensionControllerSpec',
    },
)


class ExtensionController(proto.Message):
    r"""ExtensionControllers are the Extensions management tools.

    Attributes:
        name (str):
            The resource name of the ExtensionController.
        display_name (str):
            Required. The display name of the
            ExtensionController.
        description (str):
            Optional. The description of the
            ExtensionController.
        extension_controller_spec (google.cloud.aiplatform_v1beta1.types.ExtensionControllerSpec):
            Required. The definition of the
            ExtensionController.
        create_time (google.protobuf.timestamp_pb2.Timestamp):
            Output only. Timestamp when this
            ExtensionController was created.
        update_time (google.protobuf.timestamp_pb2.Timestamp):
            Output only. Timestamp when this
            ExtensionController was most recently updated.
        etag (str):
            Used to perform consistent read-modify-write
            updates. If not set, a blind "overwrite" update
            happens.
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )
    display_name: str = proto.Field(
        proto.STRING,
        number=2,
    )
    description: str = proto.Field(
        proto.STRING,
        number=3,
    )
    extension_controller_spec: 'ExtensionControllerSpec' = proto.Field(
        proto.MESSAGE,
        number=4,
        message='ExtensionControllerSpec',
    )
    create_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=5,
        message=timestamp_pb2.Timestamp,
    )
    update_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=6,
        message=timestamp_pb2.Timestamp,
    )
    etag: str = proto.Field(
        proto.STRING,
        number=7,
    )


class ExtensionControllerSpec(proto.Message):
    r"""ExtensionController configurations.

    Attributes:
        extensions (MutableSequence[str]):
            Required. List of resource names of
            Extensions used in the Controller.
    """

    extensions: MutableSequence[str] = proto.RepeatedField(
        proto.STRING,
        number=6,
    )


__all__ = tuple(sorted(__protobuf__.manifest))
