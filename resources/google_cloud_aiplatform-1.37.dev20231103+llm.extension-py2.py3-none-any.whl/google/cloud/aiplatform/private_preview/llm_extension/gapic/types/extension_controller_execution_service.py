# -*- coding: utf-8 -*-
# Copyright 2023 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from __future__ import annotations

from typing import MutableMapping, MutableSequence

import proto  # type: ignore


__protobuf__ = proto.module(
    package='google.cloud.aiplatform.v1beta1',
    manifest={
        'QueryRequest',
        'QueryResponse',
    },
)


class QueryRequest(proto.Message):
    r"""Request message for
    [ExtensionControllerExecutionService.Query][google.cloud.aiplatform.v1beta1.ExtensionControllerExecutionService.Query].

    Attributes:
        name (str):
            Required. The name of the ExtensionController resource to
            use. Format:
            ``projects/{project}/locations/{location}/extensionControllers/{extension_controller}``
        query (google.cloud.aiplatform_v1beta1.types.QueryRequest.Query):
            Required. User provided input query message.
    """

    class Query(proto.Message):
        r"""User provided query message.

        Attributes:
            query (str):
                Required. The query from user.
        """

        query: str = proto.Field(
            proto.STRING,
            number=1,
        )

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )
    query: Query = proto.Field(
        proto.MESSAGE,
        number=2,
        message=Query,
    )


class QueryResponse(proto.Message):
    r"""Response message for
    [ExtensionControllerExecutionService.Query][google.cloud.aiplatform.v1beta1.ExtensionControllerExecutionService.Query]

    Attributes:
        response (str):
            Response to the user's query.
        metadata (google.cloud.aiplatform_v1beta1.types.QueryResponse.QueryResponseMetadata):
            Metadata related to the query execution.
    """

    class QueryResponseMetadata(proto.Message):
        r"""Metadata related to the query execution.

        .. _oneof: https://proto-plus-python.readthedocs.io/en/stable/fields.html#oneofs-mutually-exclusive-fields

        Attributes:
            steps (MutableSequence[google.cloud.aiplatform_v1beta1.types.QueryResponse.QueryResponseMetadata.ReAgentSteps]):
                ReAgent execution steps.
            use_creativity (bool):
                Whether the reasoning agent used creativity
                (instead of extensions provided) to build the
                response.

                This field is a member of `oneof`_ ``_use_creativity``.
        """

        class ReAgentSteps(proto.Message):
            r"""ReAgent execution steps.

            .. _oneof: https://proto-plus-python.readthedocs.io/en/stable/fields.html#oneofs-mutually-exclusive-fields

            Attributes:
                thought (str):
                    Planner's thought.
                extension_invoked (str):
                    Planner's choice of extension to invoke.
                extension_instruction (str):
                    Planner's instruction to the extension.
                response (str):
                    Response of the extension.
                success (bool):
                    When set to False, either the extension fails
                    to execute or the response cannot be summarized.

                    This field is a member of `oneof`_ ``_success``.
                error (str):
                    Error messages from the extension or during
                    response parsing.

                    This field is a member of `oneof`_ ``_error``.
            """

            thought: str = proto.Field(
                proto.STRING,
                number=1,
            )
            extension_invoked: str = proto.Field(
                proto.STRING,
                number=2,
            )
            extension_instruction: str = proto.Field(
                proto.STRING,
                number=3,
            )
            response: str = proto.Field(
                proto.STRING,
                number=4,
            )
            success: bool = proto.Field(
                proto.BOOL,
                number=5,
                optional=True,
            )
            error: str = proto.Field(
                proto.STRING,
                number=6,
                optional=True,
            )

        steps: MutableSequence['QueryResponse.QueryResponseMetadata.ReAgentSteps'] = proto.RepeatedField(
            proto.MESSAGE,
            number=1,
            message='QueryResponse.QueryResponseMetadata.ReAgentSteps',
        )
        use_creativity: bool = proto.Field(
            proto.BOOL,
            number=2,
            optional=True,
        )

    response: str = proto.Field(
        proto.STRING,
        number=1,
    )
    metadata: QueryResponseMetadata = proto.Field(
        proto.MESSAGE,
        number=2,
        message=QueryResponseMetadata,
    )


__all__ = tuple(sorted(__protobuf__.manifest))
